#! /usr/bin/env python

import rospy

import actionlib

import actionlib_tutorials.msg

def execute_cb(self, goal,feedback,result,action_name,sas1):
        # helper variables
        r = rospy.Rate(1)
        success = True
        
        # append the seeds for the fibonacci sequence
        feedback.sequence = []
        feedback.sequence.append(0)
        feedback.sequence.append(1)
        
  
        
        # start executing the action
        for i in range(1, goal.order):
            # check that preempt has not been requested by the client
            if sas1.is_preempt_requested():
               
                sas1.set_preempted()
                success = False
                break
            feedback.sequence.append(feedback.sequence[i] + feedback.sequence[i-1])
            # publish the feedback
            sas1.publish_feedback(self._feedback)
            # this step is not necessary, the sequence is computed at 1 Hz for demonstration purposes
            r.sleep()
          
        if success:
            result.sequence = feedback.sequence
          
            sas1.set_succeeded(result)

def FibonacciAction():
    feedback = actionlib_tutorials.msg.FibonacciFeedback()
    result = actionlib_tutorials.msg.FibonacciResult()
    action_name='fibonacci_sas'
    sas1 = actionlib.SimpleActionServer(action_name, actionlib_tutorials.msg.FibonacciAction, execute_cb=my_execute_cb, auto_start = False)	           
    sas1.start()
        
if __name__ == '__main__':
    rospy.init_node('fibonacci')
    server = FibonacciAction()
    rospy.spin()
